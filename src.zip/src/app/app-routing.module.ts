import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AdminGuardService } from "./admin-guard.service";
import { GuardService } from "./guard.service";
import { HomeComponent } from "./home/home.component";
import { LoginComponent } from "./shared/login/login.component";
import { CsvuploadComponent } from "./csvupload/csvupload.component";

const routes: Routes = [
  {component: LoginComponent, path: "login" },
  {component: HomeComponent, path: "home" },
  {component: CsvuploadComponent, path: "csvupload" },
  {path: "**", redirectTo: "csvupload" }];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)
  ]})

export class AppRoutingModule { }
