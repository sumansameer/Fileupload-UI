import { Component, OnInit } from "@angular/core";
import { OwnerService } from "./owner.service";

@Component({
  selector: "app-ownerdialog",
  styleUrls: ["./ownerdialog.component.css"],
  templateUrl: "./ownerdialog.component.html",
})
export class OwnerdialogComponent implements OnInit {
  public owner;
  public errorMessage;
  constructor(private ownerDetail: OwnerService) { }
  public getOwnerdata() {
    this.errorMessage = null;
    this.ownerDetail.getowner().subscribe(
      (response) => {
        this.owner = response;
      },
      (error) => this.errorMessage = error.error.message,
    );
  }

  public ngOnInit() {
    this.getOwnerdata();
  }

}
