import { Injectable } from "@angular/core";
import { HttpClient } from "../../../node_modules/@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";

@Injectable({
  providedIn: "root",
})
export class OwnerService {
  public url = "http://localhost:3000/owner";
  public propObj;
  constructor(private http: HttpClient) { }
  public setpropObj(prop) {
    this.propObj = prop;
  }

  public getowner(): Observable<any> {
    return this.http.get<any>(`${this.url}/${this.propObj}`);
  }
}
