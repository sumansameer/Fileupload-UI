import { Component, OnInit } from "@angular/core";
import { MatSnackBar } from "@angular/material";
import { log } from "util";
import { Router } from "../../../node_modules/@angular/router";
import { logging } from "../../../node_modules/protractor";
import { HomeService } from "./home.service";

@Component({
  selector: "app-home",
  styleUrls: ["./home.component.css"],
  templateUrl: "./home.component.html",
})
export class HomeComponent implements OnInit {
  public locations: string[];
  public errorMessage: null;
  public locationArea = "";
  public areaSearched = [];
  public pId = [];
  constructor(private service: HomeService, private router: Router, private snackBar: MatSnackBar) {

   }

  // imgUrl:"../../assets/h8.jpg"
  public getUrl() {
    return "url('../../assets/Homepage.jpg')";
  }

  public ngOnInit() {
    //  this.search_home();
  }

  public openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
      horizontalPosition: "center",
      panelClass: ["snackbar-position", "gray-snackbar"],
      verticalPosition: "top",
    });
  }
  // public search_home() {
  //   this.service.search().subscribe((data) => {
  //     this.locations = data;
  //   },
  //   (err) => {this.errorMessage = err.error.message; });
  // }

  // public buy(location) {
  //   this.locationArea = location.area;
  //   this.service.search().subscribe((res) => {
  //     this.areaSearched = res;
  //     this.areaSearched.forEach((loc) => {
  //       if (loc.area === this.locationArea) {
  //         this.pId = loc.propertyIds;
  //         if (this.pId.length > 0) {
  //           this.router.navigate(["/buy", this.pId]);
  //         } else {
  //           this.openSnackBar("No property available on this location", "OK");
  //         }
  //       }
  //     });
  //   });
  // }
}
