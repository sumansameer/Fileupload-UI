import { Location } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material";
import { Router } from "@angular/router";
import { log } from "util";
import { AppComponent } from "../../app.component";
// import { AppComponent} from "../app.component";
import { LoginService } from "./loginService";

@Component({
  selector: "app-login",
  styleUrls: ["./login.component.css"],
  templateUrl: "./login.component.html",
})
export class LoginComponent implements OnInit {

  public errorMessage: string;
  public loginForm: FormGroup;
  public registerPage = false;
  public contactNo = "";
  public emailId = "";
  public hide = true;
  public key = false;
  public show = true;

  constructor(private snackBar: MatSnackBar, private location: Location, private fb: FormBuilder,
              private router: Router, private loginService: LoginService, private app: AppComponent) {
    sessionStorage.setItem("PreviousUrl", sessionStorage.getItem("CurrentUrl"));
    sessionStorage.setItem("CurrentUrl", this.router.url);
  }

  public ngOnInit() {
    window.scrollTo(0, 0);
    // form is created on page load
    this.loginForm = this.fb.group({
      // contactEmail: ["", [Validators.required, Validators.pattern
      //   (/^([a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?)|[7-9][0-9]{9}$/)]],
      userName: ["", Validators.required],
      emailId: [""],
      password: ["", [Validators.required, Validators.pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{7,20}$/)]]
    });
  }

public openSnackBar(message: string, action: string) {
  this.snackBar.open(message, action, {
    duration: 5000,
    horizontalPosition: "center",
    panelClass: ["snackbar-position", "green-snackbar"],
    verticalPosition: "top",
  });
}

public login() {

  // this.validateContactEmail(this.loginForm.value.contactEmail);

  this.loginService.login(this.loginForm.value).subscribe(
    (response) => {
      sessionStorage.setItem("phoneNo", response[0].phoneNo);
      sessionStorage.setItem("userName", response[0].userName);
      sessionStorage.setItem("emailId", response[0].emailId);
      sessionStorage.setItem("role", response[0].role);
      this.openSnackBar("Logged in successfully", "Ok");
      if (this.loginForm.value.userName === "admin") {
        this.router.navigate(["/admin"]);
      } else {
        this.router.navigate(["/home"]);
      }
      this.errorMessage = null;
      this.app.reload();
    },
    (errorResponse) => {
     this.errorMessage = "Invalid Credentials";
     sessionStorage.clear();
    },

  );
}

public validateContactEmail(inputtxt) {
  const contact = /^\d{10}$/;
  if (inputtxt.match(contact)) {
    return this.loginForm.value.phoneNo = inputtxt;
  } else {
    return this.loginForm.value.emailId = inputtxt;
  }
}

public getRegisterPage() {
  this.registerPage = true;
  // open register page if the user is not registered already
  this.router.navigate(["/register"]);
  }
}
