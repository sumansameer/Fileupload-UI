import { Injectable } from "@angular/core";
import { CanActivate, Router} from "@angular/router";
import { MatSnackBar } from "node_modules/@angular/material";

@Injectable({
  providedIn: "root",
})
export class GuardService implements CanActivate {

  constructor(private router: Router, private snackBar: MatSnackBar) { }

  public openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
      horizontalPosition: "center",
      panelClass: ["snackbar-position", "gray-snackbar"],
      verticalPosition: "top",
    });
  }

  public canActivate(): boolean {
  const userName = sessionStorage.getItem("userName");
  const iconName = sessionStorage.getItem("icon");

  if (userName === null && iconName === "sell") {
      this.openSnackBar("Please Login to Post Properties", "Ok");
      return false;
    } else if (userName === null && iconName === "profile") {
      this.openSnackBar("Please Login to Access Profile Page", "Ok");
      return false;
    } else if (userName === null && iconName === "theatres") {
      if(this.router.url === '/theatres') {
        this.openSnackBar("Please Login to access Theatres", "Ok");
      }
      this.openSnackBar("Please Login to access Theatres", "Ok");
      return false;
    } else if (userName === null && iconName === "movies") {
      if (this.router.url === '/movies'){
        this.openSnackBar("Please Login to access Movies", "Ok");
      }
      this.openSnackBar("Please Login to access Movies", "Ok");
    } else {
      return true;
    }
   }
}
