import { Component, Inject, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { CsvuploadService } from './csvupload.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-csvupload',
  templateUrl: './csvupload.component.html',
  styleUrls: ['./csvupload.component.css']
})

export class CsvuploadComponent implements OnInit {
     //array varibales to store csv data
  lines = []; //for headings
  linesR = []; // for rows
  public file:File;
  public errorMessage;
  public successMessage;
  public uploaded;
  public data;
  public receivedFile;
  public outputuploader;
  public outputprocess;
  public processeddata: any = [];
  fileToUpload: File = null;
  public filename;
  
  constructor( @Inject(DOCUMENT) private _document: Document, private router: Router, private snackBar: MatSnackBar, private uploadServ: CsvuploadService) {

   }

  //Background image
  public getUrl() {
    return "url('../../assets/file.webp')";
  }

  public ngOnInit() {
    sessionStorage.setItem("filename", "");
    this.filename = sessionStorage.getItem("filename"); 
  }

  //Snackbar Popup
  public openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
      horizontalPosition: "center",
      panelClass: ["snackbar-position", "gray-snackbar"],
      verticalPosition: "top",
    });
  }

   
  //File upload function
  changeListener(files: FileList){
     console.log(files);
     console.log("Hi")
    //  if(files && files.length > 0) {
    //     let file : File = files.item(0); 
    //     this.upload(files);
    //     }
    this.fileToUpload = files.item(0);
    console.log(this.fileToUpload)
    console.log("Hello")
    console.log(this.fileToUpload.name.substr(-4))
    console.log("hello123")
    if(this.fileToUpload.name.substr(-4)==".csv"){
      this.uploadFileToActivity(this.fileToUpload)
    } else {
      this.openSnackBar("Please choose CSV files", "OK");
    } 
  }


  uploadFileToActivity(file) {
      console.log(file)
      const formData: FormData = new FormData();
      formData.append('file', file, file.name);
      console.log(file.name)
      console.log("Suman")
      console.log("Sameer")
      sessionStorage.setItem("filename", file.name);
      this.uploadServ.postFile(formData).subscribe(data => {
      // do something, if upload success
      console.log("success")
      this.openSnackBar("Uploaded Successfully", "OK");
      this.uploaded = "Uploaded Successfully";
      this.ngOnInit();
      }, error => {
        console.log("error");
        this.openSnackBar("Some Error Occured", "OK");
        this.uploaded = "Failure";
      });
    }
    
    public ProcessData() {
      this.filename = sessionStorage.getItem("filename"); 
      console.log("Entered Process Data")
      this.uploaded = "";
        this.uploadServ.processdata(this.filename).subscribe (
          (response) => {
            console.log(response)
          },
          (error) => { 
            this.errorMessage = error.error.message;
            this.openSnackBar("Some Error Occured", "OK");
          }
        )
      }
     

    public cancel(){
      this.uploaded = "";
      this._document.defaultView.location.reload();
    }

    
  

  
}


    // public upload(files){
    //   this.errorMessage = null;
    //     this.successMessage = null;
    //     this.openSnackBar("Uploaded Successfully", "OK");
    //     this.uploadServ.upload(files).subscribe (
    //       (response) => {
    //         this.file = response;
    //         this.successMessage = "Uploaded CSV File successfully";
    //         this.openSnackBar("Uploaded Successfully", "OK");
    //       },
    //       (error) => {
    //         this.errorMessage = "Some error occured";
    //         this.openSnackBar("Some error occured", "OK");
    //     }
    //     )   
    // }
   




  // READING & PRINTING THE CSV VALUES
  //         console.log(file.name);
  //         console.log(file.size);
  //         console.log(file.type);
  //         let reader: FileReader = new FileReader();
  //         reader.readAsText(file);
  //         reader.onload = (e) => {
  //          let csv: any = reader.result;
  //          let allTextLines = [];
  //          allTextLines = csv.split(/\r|\n|\r/);
  //         // console.log(allTextLines);
  //         //Table Headings
  //          let headers = allTextLines[0].split(';');
  //          let data = headers;
  //          let tarr = [];
  //          for (let j = 0; j < headers.length; j++) {
  //            tarr.push(data[j]);
  //          }
  //          //Pusd headinf to array variable
  //          this.lines.push(tarr);
           
          
  //          // Table Rows
  //          let tarrR = [];
  //          //Create formdata object
  //          var myFormData = new FormData();
  //          let arrl = allTextLines.length;
  //          let rows = [];
           
  //          for(let i = 1; i < arrl; i++){
  //          rows.push(allTextLines[i].split(';'));
  //          if(allTextLines[i]!=""){
  //          // Save file data into formdata varibale  
  //          myFormData.append("data"+i, allTextLines[i]);
  //        }
  //          }
          
  //          for (let j = 0; j < arrl; j++) {
            
             
              
  //              tarrR.push(rows[j]);
  //              tarrR = tarrR.filter(function(i){ return i != ""; });
               
               
  //              // Begin assigning parameters
  //             //Push rows to array variable
  // this.linesR.push(tarrR);
  //Sending post request with data to php file

