import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { AppConfig, initConfig } from '../../app-config';


@Injectable({
  providedIn: 'root'
})
export class CsvuploadService {


  public url = "http://localhost:5001/process";
  public uploader = "http://localhost:5001/uploader"

 

  constructor(private http: HttpClient, private appconfig: AppConfig) { }
  postFile(fileToUpload: FormData): Observable<boolean> {
    console.log(fileToUpload)

    const headers = { 'Authorization': 'Bearer my-token', 'My-Custom-Header': 'foobar' }
    const endpoint = 'http://localhost:5001/uploader';
    // const formData: FormData = new FormData();
    // formData.append('file', fileToUpload);
    console.log(fileToUpload)
    return this.http.post<any>(this.appconfig.baseUrl, fileToUpload);

      // .map(() => { return true; })
      // .catch((e) => this.handleError(e));
}




public processdata(filename): Observable<any> {
  let headers = new Headers();
headers.append('Content-Type', 'application/json');
headers.append('filename', filename);
let params = new HttpParams();
    params = params.append('file', filename);
    
// let params = new URLSearchParams();
// params.append("someParamKey", this.someParamValue)

  console.log("pass the file name via");
  console.log(params)
  return this.http.get<any>(this.url, { params: params });
//   this.http.get<any>( 'assets/config.json' ).map( result => result.PARAM_API_URL ).subscribe( 
//     api_url => {
//         console.log("Hi")
//     }
// );
}


// createContrat(fileToUpload: File, newContrat: Contrat): Observable<boolean> {  
//   let headers = new Headers();
//   const endpoint = Api.getUrl(Api.URLS.createContrat));    
//   const formData: FormData =new FormData();    
//   formData.append('fileKey', fileToUpload, FileToUpload.name);    
//   let body newContrat.gup(this.auth.getCurrentUser().token);     
//   return this.http      
//   .post(endpoint, formData, body)      
//   .map(() => {        
//     return true;      
//   })  
// }


  // public upload(data: any): Observable<any> {
  //   console.log("Entered")
  //   console.log(data);
  //   return this.http.post<any>(this.url, data);
  // }
}
