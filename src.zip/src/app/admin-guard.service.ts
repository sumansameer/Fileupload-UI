import { Injectable } from "@angular/core";
import { CanActivate, Router } from "@angular/router";

@Injectable({
  providedIn: "root",
})
export class AdminGuardService {

  constructor(private router: Router) { }
  public canActivate(): boolean {
    const userName = sessionStorage.getItem("name");
    if (userName === "admin") {
      return true;
    } else {
      this.router.navigate(["/home"]);
      return false;
    }
   }
}
